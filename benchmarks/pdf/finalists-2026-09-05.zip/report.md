# PDF benchmark

One run per cell. Agent-checked references; human review pending. Closure accuracy is scored only where the reference has explicit closure labels. Costs are not verified billing data.

F1 includes day, type, time and literal pool label. No aggregate F1 is shown for incomplete groups.

| Candidate | Track | Scored | Session F1 | Exact session grids | Exact date windows | Checked fields match | Mean seconds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| astra | image | 9/9 | 0.9167 | 6/9 | 9/9 | 6/9 | 46.0 |
| flash-3.8 | text | 0/9 | — | 0/9 | 0/9 | 0/9 | 9.5 |
| gpt-5.5 | text | 9/9 | 0.9722 | 8/9 | 9/9 | 8/9 | 30.0 |
| grok-cursor | text | 8/9 | — | 7/9 | 8/9 | 7/9 | 59.6 |

## Unscored cells

- flash-3.8 / text / rossi-spring: schema_invalid
- flash-3.8 / text / mlk-fall: schema_invalid
- flash-3.8 / text / garfield-maintenance: schema_invalid
- flash-3.8 / text / rossi-spring: schema_invalid
- flash-3.8 / text / mlk-fall: schema_invalid
- flash-3.8 / text / garfield-maintenance: schema_invalid
- flash-3.8 / text / rossi-spring: schema_invalid
- grok-cursor / text / mlk-fall: schema_invalid
- flash-3.8 / text / mlk-fall: schema_invalid
- flash-3.8 / text / garfield-maintenance: schema_invalid
