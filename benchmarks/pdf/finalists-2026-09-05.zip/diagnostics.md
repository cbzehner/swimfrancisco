# Extraction diagnostic

Separate from strict output-contract results. Decode only one complete extraction JSON object; do not repair values. Ambiguous or schema-invalid objects stay unscored. Execution failures and timeouts are never rescued.

Literal F1 retains pool identity. Pool-label pairs categorize differences; they do not change the score. Other missing/extra rows may represent wrong days, times, types, omissions, or duplicates.

| Candidate | Track | Strict passes | Valid objects | Literal session F1 | Pool-label pairs | Other missing / extra | Date windows | Checked fields |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| astra | image | 9/9 | 9/9 | 0.9167 | 12 | 0 / 0 | 9/9 | 6/9 |
| flash-3.8 | text | 0/9 | 9/9 | 0.9444 | 8 | 0 / 0 | 9/9 | 7/9 |
| gpt-5.5 | text | 9/9 | 9/9 | 0.9722 | 4 | 0 / 0 | 9/9 | 8/9 |
| grok-cursor | text | 8/9 | 9/9 | 0.9722 | 4 | 0 / 0 | 9/9 | 8/9 |
