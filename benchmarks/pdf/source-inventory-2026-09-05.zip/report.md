# PDF benchmark

One run per cell. Agent-checked references; human review pending. Closure accuracy is scored only where the reference has explicit closure labels. Costs are not verified billing data.

F1 includes day, type, time and literal pool label. No aggregate F1 is shown for incomplete groups.

| Candidate | Track | Scored | Session F1 | Exact session grids | Exact date windows | Checked fields match | Mean seconds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.5-api | source | 21/21 | 0.9586 | 18/21 | 21/21 | 18/21 | 22.4 |
