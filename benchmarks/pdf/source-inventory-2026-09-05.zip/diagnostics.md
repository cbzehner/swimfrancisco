# Extraction diagnostic

Separate from strict output-contract results. Decode only one complete extraction JSON object; do not repair values. Ambiguous or schema-invalid objects stay unscored. Execution failures and timeouts are never rescued.

Literal F1 retains pool identity. Pool-label pairs categorize differences; they do not change the score. Other missing/extra rows may represent wrong days, times, types, omissions, or duplicates.

| Candidate | Track | Strict passes | Valid objects | Literal session F1 | Pool-label pairs | Other missing / extra | Date windows | Checked fields |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.5-api | source | 21/21 | 21/21 | 0.9586 | 18 | 0 / 0 | 21/21 | 18/21 |
