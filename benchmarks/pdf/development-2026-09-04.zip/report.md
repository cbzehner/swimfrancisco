# Development PDF benchmark

One run per cell. Agent-checked references; human review pending. Closure accuracy is scored only for North Beach. Costs are not verified billing data.

F1 includes day, type, time and literal pool label. No aggregate F1 is shown for incomplete groups.

| Candidate | Track | Scored | Session F1 | Exact session grids | Exact date windows | Checked fields match | Mean seconds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| astra | image | 4/4 | 1.0000 | 4/4 | 4/4 | 4/4 | 62.2 |
| astra | text | 4/4 | 0.9381 | 1/4 | 4/4 | 1/4 | 59.9 |
| composer | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 42.1 |
| fable | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 46.2 |
| fable-5.1 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 43.5 |
| flash-3.7 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 39.8 |
| flash-3.8 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 14.0 |
| flash-lite-3.1 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 19.8 |
| flash-lite-3.5 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 6.2 |
| gemini-pro | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 72.6 |
| glm | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 39.6 |
| gpt-5.5 | image | 4/4 | 0.9897 | 3/4 | 4/4 | 3/4 | 43.3 |
| gpt-5.5 | text | 4/4 | 0.9948 | 3/4 | 4/4 | 3/4 | 41.3 |
| gpt-mini | image | 4/4 | 0.9326 | 1/4 | 4/4 | 1/4 | 115.4 |
| gpt-mini | text | 2/4 | — | 1/4 | 2/4 | 1/4 | 163.1 |
| gpt-nano | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 78.7 |
| grok-4.5 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 42.4 |
| grok-4.6 | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 12.5 |
| grok-cursor | text | 4/4 | 1.0000 | 4/4 | 4/4 | 4/4 | 97.5 |
| haiku | text | 0/4 | — | 0/4 | 0/4 | 0/4 | — |
| kimi | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 14.6 |
| luna | image | 4/4 | 0.9381 | 2/4 | 4/4 | 2/4 | 49.1 |
| luna | text | 4/4 | 0.8958 | 0/4 | 4/4 | 0/4 | 43.9 |
| luna-pi | text | 4/4 | 0.9231 | 1/4 | 4/4 | 1/4 | 54.7 |
| opus | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 39.7 |
| production-baseline | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 23.6 |
| sol | image | 4/4 | 0.9278 | 1/4 | 4/4 | 1/4 | 53.1 |
| sol | text | 4/4 | 0.9381 | 1/4 | 4/4 | 1/4 | 57.2 |
| sonnet | text | 0/4 | — | 0/4 | 0/4 | 0/4 | 147.9 |
| spark | text | 4/4 | 0.4198 | 0/4 | 4/4 | 0/4 | 38.1 |
| terra | image | 4/4 | 0.9691 | 1/4 | 4/4 | 1/4 | 41.4 |
| terra | text | 4/4 | 0.9223 | 1/4 | 4/4 | 1/4 | 45.4 |

## Unscored cells

- haiku / text / north-beach-expired: blocked_auth
- haiku / text / hamilton-fall: blocked_auth
- haiku / text / balboa-fall: blocked_auth
- haiku / text / balboa-interim: blocked_auth
- flash-lite-3.1 / text / north-beach-expired: schema_invalid
- flash-lite-3.1 / text / hamilton-fall: schema_invalid
- flash-lite-3.1 / text / balboa-fall: schema_invalid
- flash-lite-3.1 / text / balboa-interim: schema_invalid
- flash-lite-3.5 / text / north-beach-expired: schema_invalid
- flash-lite-3.5 / text / hamilton-fall: schema_invalid
- flash-lite-3.5 / text / balboa-fall: schema_invalid
- flash-lite-3.5 / text / balboa-interim: schema_invalid
- grok-4.5 / text / north-beach-expired: execution_error
- grok-4.5 / text / hamilton-fall: execution_error
- grok-4.5 / text / balboa-fall: execution_error
- grok-4.5 / text / balboa-interim: execution_error
- grok-4.6 / text / north-beach-expired: execution_error
- grok-4.6 / text / hamilton-fall: execution_error
- grok-4.6 / text / balboa-fall: execution_error
- grok-4.6 / text / balboa-interim: execution_error
- production-baseline / text / north-beach-expired: schema_invalid
- production-baseline / text / hamilton-fall: schema_invalid
- production-baseline / text / balboa-fall: schema_invalid
- production-baseline / text / balboa-interim: schema_invalid
- gpt-mini / text / hamilton-fall: timeout
- gpt-mini / text / balboa-interim: timeout
- gpt-nano / text / north-beach-expired: schema_invalid
- gpt-nano / text / hamilton-fall: schema_invalid
- gpt-nano / text / balboa-fall: schema_invalid
- gpt-nano / text / balboa-interim: schema_invalid
- opus / text / north-beach-expired: schema_invalid
- opus / text / hamilton-fall: schema_invalid
- opus / text / balboa-fall: schema_invalid
- opus / text / balboa-interim: schema_invalid
- sonnet / text / north-beach-expired: schema_invalid
- sonnet / text / hamilton-fall: timeout
- sonnet / text / balboa-fall: schema_invalid
- sonnet / text / balboa-interim: timeout
- fable / text / north-beach-expired: schema_invalid
- fable / text / hamilton-fall: schema_invalid
- fable / text / balboa-fall: schema_invalid
- fable / text / balboa-interim: schema_invalid
- fable-5.1 / text / north-beach-expired: schema_invalid
- fable-5.1 / text / hamilton-fall: schema_invalid
- fable-5.1 / text / balboa-fall: schema_invalid
- fable-5.1 / text / balboa-interim: schema_invalid
- flash-3.8 / text / north-beach-expired: schema_invalid
- flash-3.8 / text / hamilton-fall: schema_invalid
- flash-3.8 / text / balboa-fall: schema_invalid
- flash-3.8 / text / balboa-interim: schema_invalid
- flash-3.7 / text / north-beach-expired: schema_invalid
- flash-3.7 / text / hamilton-fall: schema_invalid
- flash-3.7 / text / balboa-fall: schema_invalid
- flash-3.7 / text / balboa-interim: schema_invalid
- gemini-pro / text / north-beach-expired: schema_invalid
- gemini-pro / text / hamilton-fall: schema_invalid
- gemini-pro / text / balboa-fall: schema_invalid
- gemini-pro / text / balboa-interim: schema_invalid
- kimi / text / north-beach-expired: schema_invalid
- kimi / text / hamilton-fall: schema_invalid
- kimi / text / balboa-fall: schema_invalid
- kimi / text / balboa-interim: schema_invalid
- glm / text / north-beach-expired: schema_invalid
- glm / text / hamilton-fall: schema_invalid
- glm / text / balboa-fall: schema_invalid
- glm / text / balboa-interim: schema_invalid
- composer / text / north-beach-expired: schema_invalid
- composer / text / hamilton-fall: schema_invalid
- composer / text / balboa-fall: schema_invalid
- composer / text / balboa-interim: schema_invalid
