# Extraction diagnostic

Separate from strict output-contract results. Decode only one complete extraction JSON object; do not repair values. Ambiguous or schema-invalid objects stay unscored. Execution failures and timeouts are never rescued.

Literal F1 retains pool identity. Pool-label pairs categorize differences; they do not change the score. Other missing/extra rows may represent wrong days, times, types, omissions, or duplicates.

| Candidate | Track | Strict passes | Valid objects | Literal session F1 | Pool-label pairs | Other missing / extra | Date windows | Checked fields |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| astra | image | 4/4 | 4/4 | 1.0000 | 0 | 0 / 0 | 4/4 | 4/4 |
| astra | text | 4/4 | 4/4 | 0.9381 | 6 | 0 / 0 | 4/4 | 1/4 |
| composer | text | 0/4 | 4/4 | 0.4876 | 33 | 15 / 22 | 4/4 | 0/4 |
| fable | text | 0/4 | 4/4 | 0.9485 | 5 | 0 / 0 | 4/4 | 3/4 |
| fable-5.1 | text | 0/4 | 4/4 | 0.9278 | 7 | 0 / 0 | 4/4 | 1/4 |
| flash-3.7 | text | 0/4 | 4/4 | 0.9485 | 5 | 0 / 0 | 4/4 | 3/4 |
| flash-3.8 | text | 0/4 | 4/4 | 0.9381 | 6 | 0 / 0 | 4/4 | 1/4 |
| flash-lite-3.1 | text | 0/4 | 4/4 | 0.5464 | 40 | 4 / 4 | 4/4 | 0/4 |
| flash-lite-3.5 | text | 0/4 | 3/4 | — | 13 | 3 / 8 | 3/4 | 0/4 |
| gemini-pro | text | 0/4 | 4/4 | 0.9897 | 1 | 0 / 0 | 4/4 | 3/4 |
| glm | text | 0/4 | 3/4 | — | 6 | 0 / 2 | 3/4 | 0/4 |
| gpt-5.5 | image | 4/4 | 4/4 | 0.9897 | 1 | 0 / 0 | 4/4 | 3/4 |
| gpt-5.5 | text | 4/4 | 4/4 | 0.9948 | 0 | 1 / 0 | 4/4 | 3/4 |
| gpt-mini | image | 4/4 | 4/4 | 0.9326 | 5 | 2 / 1 | 4/4 | 1/4 |
| gpt-mini | text | 2/4 | 2/4 | — | 2 | 2 / 3 | 2/4 | 1/4 |
| gpt-nano | text | 0/4 | 4/4 | 0.5843 | 17 | 28 / 12 | 4/4 | 0/4 |
| grok-4.5 | text | 0/4 | 0/4 | — | 0 | 0 / 0 | 0/4 | 0/4 |
| grok-4.6 | text | 0/4 | 0/4 | — | 0 | 0 / 0 | 0/4 | 0/4 |
| grok-cursor | text | 4/4 | 4/4 | 1.0000 | 0 | 0 / 0 | 4/4 | 4/4 |
| haiku | text | 0/4 | 0/4 | — | 0 | 0 / 0 | 0/4 | 0/4 |
| kimi | text | 0/4 | 4/4 | 0.6218 | 36 | 1 / 0 | 4/4 | 0/4 |
| luna | image | 4/4 | 4/4 | 0.9381 | 6 | 0 / 0 | 4/4 | 2/4 |
| luna | text | 4/4 | 4/4 | 0.8958 | 7 | 4 / 2 | 4/4 | 0/4 |
| luna-pi | text | 4/4 | 4/4 | 0.9231 | 6 | 1 / 2 | 4/4 | 1/4 |
| opus | text | 0/4 | 4/4 | 0.9485 | 5 | 0 / 0 | 4/4 | 3/4 |
| production-baseline | text | 0/4 | 4/4 | 0.8691 | 6 | 8 / 5 | 4/4 | 0/4 |
| sol | image | 4/4 | 4/4 | 0.9278 | 7 | 0 / 0 | 4/4 | 1/4 |
| sol | text | 4/4 | 4/4 | 0.9381 | 6 | 0 / 0 | 4/4 | 1/4 |
| sonnet | text | 0/4 | 2/4 | — | 0 | 0 / 0 | 2/4 | 2/4 |
| spark | text | 4/4 | 4/4 | 0.4198 | 15 | 48 / 16 | 4/4 | 0/4 |
| terra | image | 4/4 | 4/4 | 0.9691 | 3 | 0 / 0 | 4/4 | 1/4 |
| terra | text | 4/4 | 4/4 | 0.9223 | 7 | 1 / 0 | 4/4 | 1/4 |
